"""numinous — CLI for Numinous Cloud.

Install:  curl -fsSL https://cloud.numinous.technology/install.sh | sh
Auth:     export NUMINOUS_API_URL=... NUMINOUS_API_KEY=...
"""

from __future__ import annotations

import argparse
import json
import sys

from .client import Numinous, NuminousError


def _out(obj) -> None:
    print(json.dumps(obj, indent=2, default=str))


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="numinous", description=__doc__)
    sub = p.add_subparsers(dest="cmd", required=True)

    tp = sub.add_parser("template", help="manage templates")
    tps = tp.add_subparsers(dest="tcmd", required=True)
    pack = tps.add_parser("pack", help="pack an environment into a template")
    pack.add_argument("--name", required=True)
    pack.add_argument("--image", help="base docker image")
    pack.add_argument("--warm", help="command to run before snapshotting")
    tps.add_parser("list", help="list templates")

    boot = sub.add_parser("boot", help="boot sandboxes from a template")
    boot.add_argument("template_id")
    boot.add_argument("--vcpu", type=int, default=2)
    boot.add_argument("--mem", type=float, default=4.0, help="GiB")
    boot.add_argument("--ttl", type=int, default=0, help="seconds; 0=default")
    boot.add_argument("--count", type=int, default=1)
    boot.add_argument("--label", action="append", default=[], help="k=v")
    boot.add_argument("--token", help="launch token (idempotency)")
    boot.add_argument("--auto-suspend", type=int, default=0, metavar="SECONDS",
                      help="suspend after N idle seconds; auto-wakes on exec")
    boot.add_argument("--gpu", type=str, default=None, metavar="TYPE",
                      help="GPU type (e.g. H100); routes to the GPU plane")
    boot.add_argument("--gpu-count", type=int, default=1)
    boot.add_argument("--gpu-max-hr", type=float, default=None,
                      help="per-GPU price ceiling in USD/hr")

    ex = sub.add_parser("exec", help="run a command in a sandbox")
    ex.add_argument("sandbox_id")
    ex.add_argument("command")
    ex.add_argument("--timeout", type=float, default=300)
    ex.add_argument("--exclusive", action="store_true",
                    help="GPU plane: take an exclusive, quiet GPU for a "
                         "perf-timed section (evicts idle residents first)")

    # GPU remoting, folded into this CLI (no separate ngpu binary): create a
    # GPU sandbox on the multiplexed plane, run a command, pull artifacts, and
    # tear down. Everything goes through the Numinous API, so no GPU-side code
    # is ever shipped in this client.
    gr = sub.add_parser("gpu", help="GPU plane helpers")
    grs = gr.add_subparsers(dest="gcmd", required=True)
    grun = grs.add_parser("run", help="run a command on a shared GPU")
    grun.add_argument("command")
    grun.add_argument("--gpu", type=str, default="H100", metavar="TYPE")
    grun.add_argument("--image", default=None, help="base docker image")
    grun.add_argument("--template", default=None, help="template id")
    grun.add_argument("--exclusive", action="store_true")
    grun.add_argument("--timeout", type=float, default=1800)
    grun.add_argument("--pull", action="append", default=[], metavar="PATH",
                      help="export this path after the run (repeatable)")
    grun.add_argument("--keep", action="store_true",
                      help="do not destroy the sandbox after the run")

    for name in ("suspend", "resume", "destroy"):
        c = sub.add_parser(name, help=f"{name} a sandbox")
        c.add_argument("sandbox_id")

    ck = sub.add_parser("checkpoint", help="freeze a running sandbox into a template")
    ck.add_argument("sandbox_id")
    ck.add_argument("--name")

    mt = sub.add_parser("metrics", help="observed cpu/mem samples")
    mt.add_argument("sandbox_id")

    exp = sub.add_parser("export", help="export a path (works after death)")
    exp.add_argument("sandbox_id")
    exp.add_argument("path")
    exp.add_argument("--to", help="s3://bucket/prefix")

    ls = sub.add_parser("ls", help="list sandboxes")
    ls.add_argument("--label")
    ls.add_argument("--state")

    us = sub.add_parser("usage", help="usage spans by label")
    us.add_argument("--label")

    vol = sub.add_parser("volume", help="manage persistent volumes")
    vs = vol.add_subparsers(dest="vcmd", required=True)
    vc = vs.add_parser("create"); vc.add_argument("--name", required=True); vc.add_argument("--size", type=float, default=10.0); vc.add_argument("--kind", choices=["sandbox","gpu"], default="sandbox")
    vs.add_parser("list")
    vd = vs.add_parser("delete"); vd.add_argument("volume_id")

    sub.add_parser("capacity", help="free capacity")
    sub.add_parser("pricing", help="current rates")

    a = p.parse_args(argv)
    nc = Numinous()
    try:
        if a.cmd == "template" and a.tcmd == "pack":
            _out(nc.templates.pack(a.name, image=a.image, warm_cmd=a.warm))
        elif a.cmd == "template" and a.tcmd == "list":
            _out(nc.templates.list())
        elif a.cmd == "boot":
            labels = dict(kv.split("=", 1) for kv in a.label)
            out = []
            for i in range(a.count):
                tok = f"{a.token}-{i}" if a.token and a.count > 1 else a.token
                out.append(nc.sandboxes.create(
                    template_id=a.template_id, vcpu=a.vcpu, mem_gib=a.mem,
                    ttl_seconds=a.ttl, labels=labels, launch_token=tok,
                    auto_suspend_idle_seconds=a.auto_suspend,
                    gpu=(a.gpu_count if a.gpu else 0), gpu_type=a.gpu,
                    gpu_max_hr=a.gpu_max_hr))
            _out(out if a.count > 1 else out[0])
        elif a.cmd == "exec":
            env = {"GPU_EXCLUSIVE": "1"} if a.exclusive else {}
            r = nc.sandboxes.exec(a.sandbox_id, a.command, timeout_sec=a.timeout,
                                  env=env)
            sys.stdout.write(r["stdout"])
            sys.stderr.write(r["stderr"])
            return r["exit_code"]
        elif a.cmd == "gpu" and a.gcmd == "run":
            sb = nc.sandboxes.create(
                template_id=a.template, image=a.image, gpu=1, gpu_type=a.gpu)
            sid = sb["id"]
            try:
                env = {"GPU_EXCLUSIVE": "1"} if a.exclusive else {}
                r = nc.sandboxes.exec(sid, a.command, timeout_sec=a.timeout,
                                      env=env)
                sys.stdout.write(r.get("stdout", ""))
                sys.stderr.write(r.get("stderr", ""))
                for pth in a.pull:
                    _out(nc.sandboxes.export(sid, pth))
                return r["exit_code"]
            finally:
                if not a.keep:
                    nc.sandboxes.destroy(sid)
        elif a.cmd == "suspend":
            _out(nc.sandboxes.suspend(a.sandbox_id))
        elif a.cmd == "resume":
            _out(nc.sandboxes.resume(a.sandbox_id))
        elif a.cmd == "destroy":
            _out(nc.sandboxes.destroy(a.sandbox_id))
        elif a.cmd == "checkpoint":
            _out(nc.sandboxes.checkpoint(a.sandbox_id, name=a.name))
        elif a.cmd == "metrics":
            _out(nc.sandboxes.metrics(a.sandbox_id))
        elif a.cmd == "export":
            _out(nc.sandboxes.export(a.sandbox_id, a.path, to=a.to))
        elif a.cmd == "ls":
            _out(nc.sandboxes.list(label=a.label, state=a.state))
        elif a.cmd == "usage":
            _out(nc.usage.query(label=a.label))
        elif a.cmd == "volume" and a.vcmd == "create":
            _out(nc.volumes.create(a.name, size_gib=a.size, kind=a.kind))
        elif a.cmd == "volume" and a.vcmd == "list":
            _out(nc.volumes.list())
        elif a.cmd == "volume" and a.vcmd == "delete":
            _out(nc.volumes.delete(a.volume_id))
        elif a.cmd == "capacity":
            _out(nc.capacity.get())
        elif a.cmd == "pricing":
            _out(nc.pricing())
        return 0
    except NuminousError as e:
        print(f"error [{e.cause}]: {e.message}", file=sys.stderr)
        # provider faults are retryable and unbilled; exit codes reflect class
        return 75 if e.is_provider_fault else 1


if __name__ == "__main__":
    raise SystemExit(main())
